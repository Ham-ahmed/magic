print("Welcome, Enigma lovers!")
import os
import socket
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Button import Button
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from enigma import eConsoleAppContainer, ePixmap
from Screens.MessageBox import MessageBox

PLUGIN_ICON = "icon.png"
PLUGIN_VERSION = "6.1"

class ProgressScreen(Screen):
    skin = """
    <screen name="ProgressScreen" position="center,center" size="640,220" title="Progressing please wait...">
        <widget name="progress_label" position="10,10" size="590,40" font="Regular;18" foregroundColor="#00f2e0" halign="center" />
        <widget name="progress_bar" position="10,50" size="600,25" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MagicPanel/icons/bar.png" zPosition="2" alphatest="on" borderWidth="1" />
        <widget name="status" position="10,80" size="590,35" font="Regular;14" halign="center" />
        <widget name="cancel_button" position="200,130" size="200,40" font="Regular;18" halign="center" foregroundColor="##00f2e0" backgroundColor="#9F1313" />
    </screen>
    """

    def __init__(self, session, command, title):
        self.session = session
        Screen.__init__(self, session)
        self.command = command
        self.title = title
        self.container = eConsoleAppContainer()
        self.container.appClosed.append(self.command_finished)
        self.container.dataAvail.append(self.command_output)
        self["status"] = Label(f"Installing: {self.title}...")
        self["progress_label"] = Label(title)
        self["progress_bar"] = Pixmap()
        self["cancel_button"] = Button("Cancel")
        self.run_command()

    def run_command(self):
        if self.container.execute(self.command):
            self["status"].setText(f"Failed to execute: {self.command}")

    def command_output(self, data):
        pass

    def command_finished(self, retval):
        self.session.openWithCallback(
            self.on_close_messagebox,
            MessageBox,
            f"{self.title} installation completed.",
            MessageBox.TYPE_INFO,
            timeout=5,
        )

    def on_close_messagebox(self, result):
        self.close()

class MagicPanel(Screen):
    skin = """
    <screen name="MagigPanelv6" position="139,159" size="1617,773" title="MagicPanel-v6">
  <widget name="main_menu" position="288,20" size="356,622" scrollbarMode="showOnDemand" itemHeight="45" font="Regular;26" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/MagicPanel/icons/menusel1.png" borderWidth="1" borderColor="#808080" />
  <widget name="status" position="8,681" size="775,36" transparent="1" font="Regular; 24" halign="center" />
  <widget name="key_red" position="206,726" size="185,25" font="Regular;18" cornerRadius="3" halign="center" backgroundColor="#b22222" />
  <widget name="key_green" position="11,726" size="185,25" font="Regular;18" cornerRadius="3" halign="center" backgroundColor="#6400" />
  <widget name="key_yellow" position="400,726" size="185,25" font="Regular;18" cornerRadius="3" halign="center" backgroundColor="#b8860b" />
  <widget name="key_blue" position="596,726" size="185,25" font="Regular;18" cornerRadius="3" halign="center" backgroundColor="#8b" />
  <widget source="global.CurrentTime" render="Label" position="1398,711" size="210,52" font="Regular; 28" halign="center" foregroundColor="#b8860b" backgroundColor="#160000" transparent="1" zPosition="6">
    <convert type="ClockToText">Format:%d.%m.%Y</convert>
  </widget>
  <widget font="Regular;30" foregroundColor="#b8860b" backgroundColor="#160000" halign="center" position="1432,665" render="Label" size="143,52" source="global.CurrentTime" transparent="1" valign="center" zPosition="5">
    <convert type="ClockToText">Default</convert>
  </widget>
  <widget name="ip_address" position="1126,686" size="290,29" font="Regular; 22" halign="left" transparent="1" backgroundColor="#160000" foregroundColor="yellow" />
  <widget name="receiver_model" position="827,654" size="290,29" font="Regular; 22" halign="left" transparent="1" backgroundColor="#160000" foregroundColor="white" />
  <widget name="image_type" position="827,682" size="290,29" font="Regular; 22" halign="left" transparent="1" backgroundColor="#160000" foregroundColor="#cccc40" />
  <widget name="image_version" position="827,712" size="290,28" font="Regular; 22" halign="left" transparent="1" backgroundColor="#160000" foregroundColor="layer-a-channelselection-foreground-ServiceDescriptionSelected" />
  <widget name="internet_status" position="1126,654" size="290,29" font="Regular; 22" halign="left" foregroundColor="green" transparent="1" backgroundColor="#160000" />
  <widget name="python_version" position="827,742" size="290,25" font="Regular; 22" halign="left" transparent="1" backgroundColor="#160000" foregroundColor="#ff8c00" />
  <widget name="background1" position="30,25" size="250,600" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MagicPanel/icons/background1.png" zPosition="1" alphatest="on" />
  <widget name="sub_menu" position="655,20" size="925,622" scrollbarMode="showOnDemand" itemHeight="45" backgroundColor="black" font="Regular;26" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/MagicPanel/icons/menusel2.png" borderWidth="1" borderColor="#808080" />
  <eLabel backgroundColor="red" cornerRadius="3" position="206,756" size="185,6" zPosition="11" />
  <eLabel backgroundColor="green" cornerRadius="3" position="11,756" size="185,6" zPosition="11" />
  <eLabel backgroundColor="yellow" cornerRadius="3" position="400,756" size="185,6" zPosition="11" />
  <eLabel backgroundColor="blue" cornerRadius="3" position="596,756" size="185,6" zPosition="11" />
  <eLabel backgroundColor="black" position="20,14" size="1572,636" transparent="0" zPosition="-23" borderWidth="1" borderColor="#808080" />
  <eLabel backgroundColor="white" position="0,651" size="1615,1" zPosition="11" />
  <eLabel backgroundColor="white" position="0,651" size="1615,1" zPosition="11" />
  <eLabel backgroundColor="white" position="0,16" size="1615,1" zPosition="11" />
  <widget name="lan" position="1097,692" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MagicPanel/icons/lan.png" zPosition="1" alphatest="on" />
  <widget name="mod" position="800,659" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MagicPanel/icons/mod.png" zPosition="1" alphatest="on" />
  <widget name="imag" position="800,688" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MagicPanel/icons/imag.png" zPosition="1" alphatest="on" />
  <widget name="ver" position="800,717" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MagicPanel/icons/ver.png" zPosition="1" alphatest="on" />
  <widget name="inter" position="1095,659" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MagicPanel/icons/inter.png" zPosition="1" alphatest="on" />
  <widget name="ppt" position="800,744" size="18,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MagicPanel/icons/ppt.png" zPosition="1" alphatest="on" />
</screen>
    """

    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)

        self.main_menu = ["1.  MyPanel", "2.  Update the panel", "3-1.    openvix-Skins", "3-2.   openspa-Skins", "3-3.   openpli-Skins", "3-4.   openBH-Skins", "3-5.   egami-Skins", "3-6.   pure2-Skins", "3-7.   openAtv-Skins", "3-8.   openHDF-Skins", "3-9.  TeaBlue-Skins", "3-10.  satdream-Skins",  "3-11.  ALL-IMAGES",  "4.  Free", "5.  Ajpanel", "6.  EPG-Guide", "7.  HAZEM-WAHBA_Channels", "8.  Channels", "9.  plugins", "10.  Novaler", "11. Others-Panel", "12. Cam-Emulator", "13. Backup-build", "14. Iptv-player", "15. Audio-files", "16. Picons", "17. Tools", "18. Multiboot", "19. remove", "20. Bootlogo All", "21. Fix-IT", "22. Others-plugin", "23. Multi-Media",]
        self.sub_menus = {
            "1.  MyPanel": [
        ("1.  install panel version 6", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel-v6/refs/heads/main/New-panel_ajpanel-HA_v6.0.sh -O - | /bin/sh"),
    ],
           "2.  Update the panel": [
        ("Update My panel", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel-v6/refs/heads/main/1New_update.sh -O - | /bin/sh"),
    ],
        "3-1.    openvix-Skins": [
        ("1.   youVixFHD_v3-Skin-Mod_H-A.....openvix 6.7.008", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/youvix/youVixFHD_v3-Skin-Mod_H-Ahmed.sh -O - | /bin/sh"),
        ("2.   YouViX_New-Skin_PosterX_4x1...openvix 6.6.013", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/youvix/skins-youVix-Mod_H-Ahmed.sh -O - | /bin/sh"),
        ("3.   YouViX_Skin_PosterX_4x1.......openvix py 3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/Skin-py3-12-2/main/YouViX-Skin6_5_003-PosterX_4x1-Mod-HA.sh -O - | /bin/sh"),
        ("4.   YouViX_Skin_PosterX_4x1........openvix6.5.001", "wget https://raw.githubusercontent.com/Ham-ahmed/Skins2024/main/YouViX-Skin_PosterX_4x1-Mod-HAhmed.sh -O - | /bin/sh"),
        ("5.   AglareFHD_v.5.3-Atv-egami-spa.........D.MNasr", "wget https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglareatv/installer.sh -O - | /bin/sh"),
    ],
        "3-2.   openspa-Skins": [
        ("1.   estuaryFHD-v5_openspa_RED_MOD-HA_py3.12.9.....", "wget https://raw.githubusercontent.com/Ham-ahmed/openspa/refs/heads/main/esturyHD-Spa-v5_red-MOD_HA.sh -O - | /bin/sh"),
        ("2.   xDreamyFHD_v.5.2.1-Atv-egami-spa.....M.Hussein", "wget https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh"),
        ("3.   E2-DarkOS_posterX..............openvix py 3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/E2-DarkOS_posterX-Mod_HAhmed.sh -O - | /bin/sh"),
        ("4.   premium-fhd-black..............openvix py 3.12", "wget https://gitlab.com/eliesat/skins/-/raw/main/all/premium-fhd/premium-fhd-black.sh -O - | /bin/sh"),
        ("5.   estuaryFHD-posterX-v..5openspa_MOD-HA_py3.12.4", "wget https://raw.githubusercontent.com/Ham-ahmed/openspa/main/estuaryHD_openspa-posterX-v.5-mod-HAhmed.sh -O - | /bin/sh"),
        ("6.   openplusFHD_posterX-v2..openspa8.3.006-MOD-H-A", "wget https://raw.githubusercontent.com/Ham-ahmed/openspa/main/openplusFHD_posterX-v2_Mod-H-Ahmed.sh -O - | /bin/sh"),
        ("7.   BlackSPAFHD_posterX.....openspa8.3.006-MOD-H-A", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/BlackSPAFHD_posterX-Mod_HAhmed.sh -O - | /bin/sh"),
        ("8.   openplusFHD_posterX.....openspa8.3.006-MOD-H-A", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/openplusFHD_posterX-Mod_HAhmed.sh -O - | /bin/sh"),
    ],
        "3-3.   openpli-Skins": [
        ("1.   GigabluePaxV4-Skin3x1_OPENPli-GCC-py3.12.1-2_Mod-H-Ahmed", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/pli/GigabluePaxV4-Skin3x1_PLi-GCC_Mod-H-Ahmed.sh -O - | /bin/sh"),
        ("2.   PLi-FullNightFHD-v1.0......H_Ahmed-py3.13-foxbob-Gcc14.2", "wget https://raw.githubusercontent.com/Ham-ahmed/pli/refs/heads/main/PLi-FullNightFHD_v1.0-Mod-HA.sh -O - | /bin/sh"),
        ("3.   AglareFHD_6.2-openpli.........................SKIN-MNasr", "wget https://raw.githubusercontent.com/Ham-ahmed/118/refs/heads/main/installer.sh -O - | /bin/sh"),
        ("4.   MaxyFHD_1.0-openpli3.12.4.....................SKIN-MNasr", "wget https://raw.githubusercontent.com/Ham-ahmed/Skins2024/main/1skins-maxy-fhd-pli_1.0_all.sh -O - | /bin/sh"),
    ],
        "3-4.   openBH-Skins": [
        ("1.   MX_PrioFHD_Mod_H-Ahmed_New_sKIN-openBH_5.5.1.008-9", "wget https://raw.githubusercontent.com/Ham-ahmed/294/refs/heads/main/Mx-PrioFHD-Skin-Mod_H-Ahmed.sh -O - | /bin/sh"),
        ("2.   MX_Slim-Line_NP_Mod_H-Ahmed_New-openBH_5.4.1.008-9", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/mx-slim/MX_Slim-Line_NP_Mod_H-Ahmed.sh -O - | /bin/sh"),
        ("3.   MX_LiveFHD_posterX-v4_New.........openBH_5.4.1.003", "wget https://raw.githubusercontent.com/Ham-ahmed/Skins2024/main/MX-LiveFHD-posterX_v4-mod-HAhmed.sh -O - | /bin/sh"),
        ("4.   MX_LiveFHD_posterX-v3_New.........openBH_5.4.1.002", "wget https://raw.githubusercontent.com/Ham-ahmed/BH-Skins/main/MX-LiveFHD-posterX-v3_mod-HAhmed.sh -O - | /bin/sh"),
    ],   
        "3-5.   egami-Skins": [
        ("1.  RED-KNIGHT-FHD-v1.0-mod-H-Ahmed.py3.13.7......", "wget https://raw.githubusercontent.com/Ham-ahmed/knight/refs/heads/main/RED-KNIGHT-FHD-v1.0-mod-HAhmed.sh -O - | /bin/sh"),
        ("2.  oDreamyFHD_mini-posterX-v2-10.5r1-2-3-4.Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/oDreamy-mini/main/oDreamyFHD_mini-posterX-v2_Mod_HAhmed.sh -O - | /bin/sh"),
        ("3.  oDreamyFHD_mini-posterX-10.5r1-2-3......Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/Skins2024/main/oDreamyFHD_mini-posterX-Mod_HA.sh -O - | /bin/sh"),
        ("4.  AglareFHD_v.4.7-Atv-egami-spa............MNasr", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/Aglaer/Aglare-FHD-4.7.sh -O - | /bin/sh"),
        ("5.  xDreamyFHD_v.3.8-Atv-egami-spa........MHussein", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/xdreamy/skins-xDreamy-v3.8.sh -O - | /bin/sh"),
        ("6.  luka-fhd_1.0-FHD_egami...................MNasr", "wget https://raw.githubusercontent.com/Ham-ahmed/206/refs/heads/main/luka-fhd_1.0_egami.sh -O - | /bin/sh"),
    ],    
        "3-6.   pure2-Skins": [
        ("21.  esturyFHD-pure2-7.4-py3.12.2.....Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/Skin-py3-12-2/main/estuaryfhd-posterX-mod3_H-Ahmed.sh -O - | /bin/sh"),
    ], 
        "3-7.   openAtv-Skins": [
        ("1.  RED-KNIGHT-FHD-v1.0-mod-H-Ahmed.py3.136-7........", "wget https://raw.githubusercontent.com/Ham-ahmed/knight/refs/heads/main/RED-KNIGHT-FHD-v1.0-mod-HAhmed.sh -O - | /bin/sh"),
        ("2.  Artemis_v1.0-mod_H-Ahmed-OPENATV-py3.13.6-7......", "wget https://raw.githubusercontent.com/Ham-ahmed/288/refs/heads/main/Artemis_-v1.0-mod_HAhmed.sh -O - | /bin/sh"),
        ("3.  Sky-Novalerx_3.0-OPENATV-py3.13.6_Mod-H-Ahmed....", "wget https://raw.githubusercontent.com/Ham-ahmed/Skins/refs/heads/main/Sky-Novalerx_3.0-MOD_HAhmed.sh -O - | /bin/sh"),
        ("4.  GigabluePaxV4-Skin3x1_OPENATV_Mod-H-Ahmed........", "wget https://raw.githubusercontent.com/Ham-ahmed/Atv/refs/heads/main/GigabluePaxV4-Skin3x1_ATV_Mod-H-Ahmed.sh -O - | /bin/sh"),
        ("5.  AglareFHD_v.5.6-Atv-egami-spa......D.Mohamed-Nasr", "wget https://raw.githubusercontent.com/Ham-ahmed/154/refs/heads/main/Aglare-FHD-v5.6.sh -O - | /bin/sh"),
        ("6.  AglareFHD_v.5.4-Atv-egami-spa......D.Mohamed-Nasr", "wget https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglareatv/installer.sh -O - | /bin/sh"),
        ("7.  MaxyFHD-v1.3-Atv-egami-spa.........D.Mohamed-Nasr", "wget https://raw.githubusercontent*com/popking159/skins/refs/heads/main/maxyatv/installer.sh -O - | /bin/sh"),
        ("8.  xDreamyFHD_v.5.8.1-Atv-egami-spa-Mahamoud-Hussein", "wget https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh"),
        ("9.  xDreamyFHD_v.5.2.1-Atv-egami-spa.Mahamoud-Hussein", "wget https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh"),
        ("10.  xDreamyFHD_v.5.2-Atv-egami-spa..Mahamoud-Hussein", "wget https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh"),    
        ("11.  xDreamyFHD_v.5.2-openAtv........Mahamoud-Hussein", "wget https://raw.githubusercontent.com/Ham-ahmed/openatv/main/metrix_skinparts_mnasr.sh -O - | /bin/sh"),
        ("12. fullhdglass17 skin 9.50...............06-05-2025 ", "wget https://raw.githubusercontent.com/Ham-ahmed/65/refs/heads/main/fullhdglass17_9.50.sh -O - | /bin/sh"),
    ],   
        "3-8.   openHDF-Skins": [
        ("1.  XionFHD-Skin posterX-v02_OpenHDF..Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/XionFHD/main/XionHDF-posterX-v02_Mod_HAhmed.sh -O - | /bin/sh"),
    ],        
        "3-9.  TeaBlue-Skins": [
        ("1.  Gigabluepaxv4FHD_3x1-teamblue-7.4-py3.1....Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/gigablue/refs/heads/main/GigabluePaxV4-Skin3x1_Mod-H-Ahmed.sh -O - | /bin/sh"),
        ("2.  Gigabluepaxv4FHD_3x1-teamblue-7.4-py3.12.4.Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/gigablue/refs/heads/main/GigabluePaxV4-Skin3x1_Mod-H-Ahmed.sh -O - | /bin/sh"),
    ],    
        "3-10.  satdream-Skins": [
        ("1.  SatDreamGrFHD-SatDreamGr-10-py3.9.9.Mod-HAhmed", "wget https://raw.githubusercontent.com/Ham-ahmed/SatDreamGr/main/Satdreamgr-HDF-posterX-v01_Mod_HAhmed.sh -O - | /bin/sh"),
    ],        
        "3-11.  ALL-IMAGES": [
        ("1.  XDREAMY-FHD_v6.1.0.....Mahamoud-Hussein", "wget https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh"),
        ("2.  XDREAMY-FHD_v6.0.0.....Mahamoud-Hussein", "wget https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh"),
        ("3.  FURY-FHD-4.6...............ISLAM.SALAMA", "wget https://raw.githubusercontent.com/islam-2412/IPKS/refs/heads/main/fury/installer.sh -O - | /bin/sh"),
        ("4.  XDREAMY-FHD_5.9.9-r95..Mahamoud-Hussein", "wget https://raw.githubusercontent.com/Insprion80/Skins/refs/heads/main/xDreamy/XDREAMY_AiO.sh-O - | /bin/sh"),
        ("5.  XDREAMY-FHD_5.9.4......Mahamoud-Hussein", "wget https://raw.githubusercontent.com/Ham-ahmed/206/refs/heads/main/installer-xdreamy.sh -O - | /bin/sh"),
    ],
           "4.  Free": [
        ("1. 36-xklass Manage playlists......07-08-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/78/refs/heads/main/36-xklass.sh -O - | /bin/sh"),
        ("2. 36-xtreamity Manage playlists .....07-08-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/78/refs/heads/main/36-xtreamity.sh -O - | /bin/sh"),
        ("3. 54-xtreamity Manage playlists...19-05-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/195/refs/heads/main/54-xklass.sh -O - | /bin/sh"),
        ("4. 54-xklass Manage playlists .....19-05-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/195/refs/heads/main/54-xtreamity.sh -O - | /bin/sh"),     
        ("5. 67-xtreamity Manage playlists...21-04-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/214/refs/heads/main/67-xtreamity.sh -O - | /bin/sh"),
        ("6. 67-xklass Manage playlists .....21-04-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/214/refs/heads/main/67-xklass.sh -O - | /bin/sh"),  
        ("7. 23-xtreamity Manage playlists...30-03-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/303/refs/heads/main/23-xtreamity.sh -O - | /bin/sh"),
        ("8. 23-xklass Manage playlists .....30-03-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/303/refs/heads/main/23-xclass.sh -O - | /bin/sh"),  
        ("9. 17-xtreamity Manage playlists...08-03-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/73/refs/heads/main/17-xtreamity.sh -O - | /bin/sh"),
        ("10. 21-xklass Manage playlists ....07-03-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/21/refs/heads/main/21-xclass.sh -O - | /bin/sh"),
        ("11. 38-Portals.....Add 38-Newportals-06032025", "wget https://raw.githubusercontent.com/Ham-ahmed/38/refs/heads/main/38-portals.sh -O - | /bin/sh"),
        ("12.205-Portals....Add 205-Newportals-28122024", "wget https://raw.githubusercontent.com/Ham-ahmed/205/refs/heads/main/205-portals.sh -O - | /bin/sh"),
        ("13.39-M3u_files_Xklass...Add 39-New_M3U-Files", "wget https://raw.githubusercontent.com/Ham-ahmed/205/refs/heads/main/39-M3u_files.sh -O - | /bin/sh"),
    ],
            "5.  Ajpanel": [
        ("1.   ajpanel-v10.8.3.", "wget https://raw.githubusercontent.com/Ham-ahmed/155/refs/heads/main/ajpanel_v10.8.3.sh -O - | /bin/sh"),   
        ("2.   ajpanel-v10.8.2.", "wget https://raw.githubusercontent.com/Ham-ahmed/105/refs/heads/main/ajpanel_v10.8.2.sh -O - | /bin/sh"),
        ("3.   ajpanel-v10.8.1.", "wget https://raw.githubusercontent.com/Ham-ahmed/154/refs/heads/main/ajpanel_v108.0.sh -O - | /bin/sh"),
        ("4.   ajpanel-v10.8.0.", "wget https://raw.githubusercontent.com/Ham-ahmed/154/refs/heads/main/ajpanel_v10.8.1.sh -O - | /bin/sh"),  
        ("5.   ajpanel-v10.7.1.", "wget https://raw.githubusercontent.com/Ham-ahmed/93/refs/heads/main/ajpanel_v10.7.1_all.sh -O - | /bin/sh"),
        ("6.   ajpanel-v10.7.0.", "wget https://raw.githubusercontent.com/Ham-ahmed/53/refs/heads/main/ajpanel_v10.7.0_all.sh -O - | /bin/sh"),
        ("7.   ajpanel-v10.6.0.", "wget https://raw.githubusercontent.com/Ham-ahmed/122/refs/heads/main/ajpanel_v10.6.0.sh -O - | /bin/sh"),
        ("8.   ajpanel-v10.5.1.", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/refs/heads/main/plugin-ajpanel_v10.5.0.sh -O - | /bin/sh"),
        ("9.   ajpanel-v10.4...", "wget https://raw.githubusercontent.com/biko-73/AjPanel/main/installer.sh -O - | /bin/sh"),
        ("10.  ajpanel-v10.2.3.", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/refs/heads/main/plugin-ajpanel_v10.2.3.sh-O - | /bin/sh"),
        ("11.  ajpanel-v10.2.2.", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/refs/heads/main/plugin-ajpanel_v10.2.2.sh -O - | /bin/sh"),
        ("12.  ajpanel-v10.2.0.", "wget https://raw.githubusercontent.com/Ham-ahmed/212/refs/heads/main/ajpanel_v10.2.0_all.sh -O - | /bin/sh"),
        ("13.  ajpanel-v10.1.0.", "wget https://raw.githubusercontent.com/biko-73/AjPanel/main/installer.sh -O - | /bin/sh"),
        ("14.  ajpanel-v10.0.0.", "wget https://raw.githubusercontent.com/biko-73/AjPanel/main/installer.sh -O - | /bin/sh"),
        ("15.  ajpanel-v9.4.0..", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/main/plugin-extensions-ajpanel_v9.4.0.sh -O - | /bin/sh"),
        ("16.  ajpanel-v9.3.0. ", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/main/plugin-extensions-ajpanel_v9.3.0_all.sh -O - | /bin/sh"),
        ("17.  ajpanel-v9.1.0..", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/main/plugin-extensions-ajpanel_v9.1.0_all.sh -O - | /bin/sh"),
        ("18.  ajpanel-v9.0.0..", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/main/plugin-extensions-ajpanel_v9.0.0_all.sh -O - | /bin/sh"),
    ],
           "6.  EPG-Guide": [
        ("1.   EpgGrabber-24.6-New_Version", "wget https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh -O - | /bin/sh"),
        ("2.   EpgGrabber-23.7............", "wget https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh -O - | /bin/sh"),
        ("3.   EpgGrabber-23.4............", "wget https://raw.githubusercontent.com/Ham-ahmed/newp/main/Epg-plugin-master-v23.4.sh -O - | /bin/sh"),
        ("4.   EpgGrabber-22.9............", "wget https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh -O - | /bin/sh"),
        ("5.   epgimport-mod-dorik1972....", "wget https://raw.githubusercontent.com/Ham-ahmed/122/refs/heads/main/epgimport-mod-dorik1972-1.9.1.sh -O - | /bin/sh"),
        ("6.   epgimport-1.9.1............", "opkg install enigma2-plugin-extensions-epgimport</item> -O - | /bin/sh"),
        ("7.   subssupport-v1.7.0-r25.....", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("8.   subssupport-v1.7.0-r10.....", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("9.   subssupport-v1.7.0-r8......", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/subssupport-1.1.0-r8-install.sh -O - | /bin/sh"),
        ("10.  newvirtualkeyboard_Subsport", "wget https://raw.githubusercontent.com/fairbird/NewVirtualKeyBoard/main/subsinstaller.sh -O - | /bin/sh"),
        ("11.  TMBD_8.6-r7_py 3.11-12.....", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins3/refs/heads/main/TMBD_8.6-r7.sh -O - | /bin/sh"),
        ("12.  subssupport-v1.7.0-r7......", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/refs/heads/main/subssupport-install.sh -O - | /bin/sh"),
        ("13.  subssupport-v1.7.0 r6......", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("14.  subssupport-v1.7.0 r5......", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("15.  subssupport-By_Mora Hosny..", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("16.  subssupport-By_Mora Hosny..", "wget https://raw.githubusercontent.com/Ham-ahmed/subsupport/main/SubsSupport.sh -O - | /bin/sh"),
        ("17.  subssupport-3.12.1.........", "wget https://raw.githubusercontent.com/Ham-ahmed/subsupport/main/SubsSupport.sh -O - | /bin/sh"),
        ("18.  jediepgxtream_2.12.........", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("19.  EPGTranslator..............", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins2/refs/heads/main/xtraevent_6.802_all.sh -O - | /bin/sh"),
        ("20.  xtraevent_6.870............", "wget https://raw.githubusercontent.com/Ham-ahmed/28/refs/heads/main/xtraevent_6.870.sh -O - | /bin/sh"),
        ("21.  xtraevent_6.840............", "wget https://raw.githubusercontent.com/Ham-ahmed/177/refs/heads/main/xtraevent_6.840.sh -O - | /bin/sh"),
        ("22.  xtraevent_6.810............", "wget https://raw.githubusercontent.com/Ham-ahmed/33/refs/heads/main/xtraevent_6.810_all.sh -O - | /bin/sh"),
        ("23.  xtraevent_6.806............", "wget https://raw.githubusercontent.com/popking159/xtraeventplugin/refs/heads/main/xtraevent-install.sh -O - | /bin/sh"),
        ("24.  xtraevent_6.801............", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/EPGTranslator-plugin.sh -O - | /bin/sh"),
        ("25.  xtraevent_6.802............", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins2/refs/heads/main/jediepgxtream_2.12.sh -O - | /bin/sh"),
        ("26.  xtraevent_6.8..............", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/refs/heads/main/xtraevent_6.801_all.sh -O - | /bin/sh"),
        ("27.  xtraevent_6.798............", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/refs/heads/main/xtraevent_6.8_all.sh -O - | /bin/sh"),
        ("28.  xtraevent-v6.7.............", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/refs/heads/main/xtraevent_6.798_all.sh -O - | /bin/sh"),
        ("29.  xtraevent-v6.6.............", "wget https://github.com/Ham-ahmed/xtra/blob/main/xtraevent-plugin_v6.7.sh -O - | /bin/sh"),
        ("30.  xtraevent-v6.2.............", "wget https://raw.githubusercontent.com/Ham-ahmed/xtra/main/xtraevent-plugin_v6.6.sh -O - | /bin/sh"),
        ("31.  xtraevent5.3...............", "wget https://raw.githubusercontent.com/Ham-ahmed/EPG/main/xtraEvent_v6.2.sh -O - | /bin/sh"),
        ("32.  xtraevent4.5...............", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/xtraevent-5.3.sh -O - | /bin/sh"),
        ("33.  xtraevent5.2...............", "wget https://gitlab.com/eliesat/extensions/-/raw/main/xtraevent/xtraevent-4.5.sh-O - | /bin/sh"),
        ("34.  jedimakerxtream............", "wget https://gitlab.com/eliesat/extensions/-/raw/main/xtraevent/xtraevent-5.3.sh -O - | /bin/sh"),
        ("35.  Epgtranslator-v1.4r2_py3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/32/refs/heads/main/translator-v1.4r2.sh -O - | /bin/sh"),
        ("36.  Tmbd-v.1.0.9_py 3.11.4-5...", "wget https://gitlab.com/eliesat/extensions/-/raw/main/jedimakerxtream/jedimakerxtream.sh -O - | /bin/sh"),
        ("37.  Tmbd-v.8.6_py 3.11.2.......", "wget https://raw.githubusercontent.com/Ham-ahmed/EPG/refs/heads/main/tmdb_1.0.9_all.sh -O - | /bin/sh"),
    ],
          "7.  HAZEM-WAHBA_Channels": [
        ("1.   HAZEM-WAHBA-motor28-08-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/28-8/refs/heads/main/HAZEM-WAHBA_Channels.sh -O - | /bin/sh"),     
        ("2.   HAZEM-WAHBA-motor10-08-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/108/refs/heads/main/HAZEM-WAHBA_Channels.sh -O - | /bin/sh"),  
        ("3.   HAZEM-WAHBA-motor04-08-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/48/refs/heads/main/HAZEM-WAHBA_Channels.sh -O - | /bin/sh"), 
        ("4.   HAZEM-WAHBA-motor02-08-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/28/refs/heads/main/HAZEM-WAHBA_Channels.sh -O - | /bin/sh"),
    ],
    
          "8.  Channels": [
        ("1.   HAZEM-WAHBA-motor04-08-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/48/refs/heads/main/HAZEM-WAHBA_Channels.sh -O - | /bin/sh"), 
        ("2.   Mohammed-Nasr-motor8-3-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/133/refs/heads/main/channels_backup_MNasr_08-03-2025.sh -O - | /bin/sh"),
        ("3.   mohamed-os-motor_31-01-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/22/refs/heads/main/channels_backup_Mohamed-OS_31-1-2025.sh -O - | /bin/sh"),
        ("4.   mohamed-os-motor_20-12-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/channels_backup_Mohamed-OS_20-12-2024.sh -O - | /bin/sh"),
        ("5.   mohamed-os-motor_12-12-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/refs/heads/main/channels_backup_20241212_MohamedOS.sh -O - | /bin/sh"),
        ("6.   mohamed-os-motor_29-11-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/212/refs/heads/main/channels_backup_20241229_vhannibal.sh -O - | /bin/sh"),
        ("7.   vhannibal-motor_29-11-2024.", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/refs/heads/main/channels_backup_Mohamed-OS_22-11-2024.sh -O - | /bin/sh"),
        ("8.   ciefp-motor_23-11-2024.....", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/refs/heads/main/channels_backup_20241123_ciefp.sh -O - | /bin/sh"),
        ("9.   mohamed-os-motor_22-11-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/refs/heads/main/channels_backup_Mohamed-OS_22-11-2024.sh -O - | /bin/sh"),
        ("10.  ciefp-motor_17-10-2024.....", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/refs/heads/main/channels_backup_Ciefp_20241017.sh -O - | /bin/sh"),
        ("11.  Samy-A-E-motor_26-9-2024...", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/refs/heads/main/channels_backup_20240924_Samy-A-E.sh -O - | /bin/sh"),
        ("12.  ciefp-motor_15-9-2024......", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_Ciefp_20240915_015044.sh -O - | /bin/sh"),
        ("13.  ciefp-motor_9-9-2024.......", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_20240909_ciefp.sh -O - | /bin/sh"),
        ("14.  Bosnia_Bouquet-16e.........", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/Bosnia_MStream_16e.sh -O - | /bin/sh"),
        ("15.  ciefp-motor_30-8-2024......", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_20240901_ciefp.sh -O - | /bin/sh"),
        ("16.  mohamed-os-motor_18-8-2024.", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_Mohamed-OS_18-08-2024.sh -O - | /bin/sh"),
        ("17.  mohamed-os-motor_8-8-2024..", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_Mohamed-OS_08-08-2024.sh -O - | /bin/sh"),
        ("18.  mohamed-os-motor_4-8-2024..", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_Mohamed-OS_04-08-2024.sh -O - | /bin/sh"),
        ("19.  mohamed-os-motor_21-7-2024.", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_Mohamed-OS_19-7-2024.sh -O - | /bin/sh"),
        ("20.  Mohammed-Nasr_motor6-7.....", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/channels_backup_MNASR_20240706.sh -O - | /bin/sh"),
        ("21.  AHMED-HUSSEIN-15-7_motor...", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_A-Hussein_20240715_141837.sh -O - | /bin/sh"),
        ("22.  mohamed-os-motor_8-7-2024..", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_Mohamed-OS_8-7-2024.sh -O - | /bin/sh"),
        ("23.  Mohammed-Nasr-motor6-7-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_MNASR_6-7-2024.sh -O - | /bin/sh"),
        ("24.  elkhamisy_motor-2-3-2025...", "wget https://raw.githubusercontent.com/Ham-ahmed/33/refs/heads/main/channels_backup_elkhamisy_2-3-2025.sh -O - | /bin/sh"),
    ],
          "9.  plugins": [
        ("1.   historyzap_selector.v1.45....", "wget https://raw.githubusercontent.com/Ham-ahmed/207/refs/heads/main/historyzap_1.0.45.sh -O - | /bin/sh"),
        ("2.   historyzap-1.0.44_py3.13_3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/306/refs/heads/main/historyzap_1.0.44.sh -O - | /bin/sh"),
        ("3.   History_Zap_1.0.38.....py3.12", "wget https://raw.githubusercontent.com/biko-73/History_Zap_Selector/main/installer.sh -O - | /bin/sh"),
        ("4.   wireguard-vpn........13.9_New", "wget https://raw.githubusercontent.com/Ham-ahmed/2412/refs/heads/main/wireguard-vpn_13.9.sh -O - | /bin/sh"),
        ("5.   wireguard-vpn............13.0", "wget https://raw.githubusercontent.com/Ham-ahmed/212/refs/heads/main/wireguard-vpn_13.0_all.sh -O - | /bin/sh"),
        ("6.   oaweather-4.0................", "wget https://raw.githubusercontent.com/Ham-ahmed/177/refs/heads/main/oaweather_4.0.sh -O - | /bin/sh"),
        ("7.   oaweather3.2.1...............", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/oaweather_3.2.1_all.sh -O - | /bin/sh"),
        ("8.   oaweather2.6.................", "wget https://raw.githubusercontent.com/Ham-ahmed/1New-P/main/oaweather.sh -O - | /bin/sh"),
        ("9.   weather-plugin...........v2.1", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/weatherplugin_2.1_all.sh -O - | /bin/sh"),
        ("10.  weatherplugin................", "wget https://raw.githubusercontent.com/Ham-ahmed/1New-P/main/weather_plugin.sh -O - | /bin/sh"),
        ("11.  TheWeather...................", "wget https://raw.githubusercontent.com/biko-73/TheWeather/main/installer.sh -O - | /bin/sh"),
        ("12.  weatherplugin-py2-py3........", "wget https://raw.githubusercontent.com/Ham-ahmed/Iptv-plugin/refs/heads/main/theweather-py2-py3_2.4_r1.sh -O - | /bin/sh"),
        ("13.  weatherplugin................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/weatherplugin/weatherplugin.sh -O - | /bin/sh"),
        ("14.  weatherplugin..........vector", "wget https://gitlab.com/eliesat/extensions/-/raw/main/weatherplugin-vector/weatherplugin-vector.sh -O - | /bin/sh"),
        ("15.  theweather...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/theweather/theweather.sh -O - | /bin/sh"),
        ("16.  youtube...........py3-git1292", "wget https://raw.githubusercontent.com/Ham-ahmed/93/refs/heads/main/youtube_py3-1292.sh -O - | /bin/sh"),
        ("17.  youtube............py3-git240", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/youtube_py3-git1240.sh -O - | /bin/sh"),
        ("18.  youtube...........py3-git1231", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins3/refs/heads/main/youtube_py3-git1231.sh -O - | /bin/sh"),
        ("19.  footonsat..............1.9.r0", "wget https://raw.githubusercontent.com/Ham-ahmed/Iptv-plugin/refs/heads/main/footonsat_1.9-r0.sh -O - | /bin/sh"),
        ("20.  footonsat....................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/footonsat/footonsat.sh -O - | /bin/sh"),
        ("21.  footonsat..............1.6.r0", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/footonsat_1.9-r0_all.sh -O - | /bin/sh"),
        ("22.  bootlogoswapper..........v2.4", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins3/refs/heads/main/bootlogoswapper_v2.4.sh -O - | /bin/sh"),
        ("23.  crashlogviewer............1.5", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins3/refs/heads/main/crashlogviewer_1.5.sh -O - | /bin/sh"),
        ("24.  crashlogviewer............1.3", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/crashlogviewer_1.3_all.sh -O - | /bin/sh"),
        ("25.  filecommander............2024", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/filecommander_mod_2024_by_lululla_all.sh -O - | /bin/sh"),
        ("26.  alternativesoftcammanager....", "wget https://gitlab.com/eliesat/extensions/-/raw/main/alternativesoftcammanager/alternativesoftcammanager.sh -O - | /bin/sh"),
        ("27.  athantimes...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/athantimes/athantimes.sh -O - | /bin/sh"),
        ("28.  bissfeedautokey..............", "wget https://gitlab.com/eliesat/extensions/-/raw/main/bissfeedautokey/bissfeedautokey.sh -O - | /bin/sh"),
        ("29.  bitrate2.0...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/bitrate/bitrate.sh -O - | /bin/sh"),
        ("30.  bouquetmakerxtream...........", "wget https://gitlab.com/eliesat/extensions/-/raw/main/bouquetmakerxtream/bouquetmakerxtream.sh -O - | /bin/sh"),
        ("31.  cacheflush...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/cacheflush/cacheflush.sh -O - | /bin/sh"),
        ("32.  crondmanager.................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/crondmanager/crondmanager.sh -O - | /bin/sh"),
        ("33.  easy-cccam...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/easy-cccam/easy-cccam.sh -O - | /bin/sh"),
        ("34.  epggrabber...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/epggrabber/epggrabber.sh -O - | /bin/sh"),
        ("35.  feedsfinder..................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/feedsfinder/feedsfinder.sh -O - | /bin/sh"),
        ("36.  freeserver...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/freeserver/freeserver.sh -O - | /bin/sh"),
        ("37.  internet-speed-test..........", "wget https://gitlab.com/eliesat/extensions/-/raw/main/internetspeedtest/internet-speed-test.sh -O - | /bin/sh"),
        ("38.  ipaudio-6.8..................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/ipaudio/ipaudio.sh -O - | /bin/sh"),
        ("39.  ipaudiopro-1.1....py-3.9-3.11", "wget https://gitlab.com/eliesat/extensions/-/raw/main/ipaudiopro/ipaudiopro.sh -O - | /bin/sh"),
        ("40.  ipchecker....................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/ipchecker/ipchecker.sh -O - | /bin/sh"),
        ("41.  acherone New plugin v1.3 ....", "wget https://raw.githubusercontent.com/Ham-ahmed/105/refs/heads/main/acherone_1.3.sh -O - | /bin/sh"),
        ("42.  simple zoom panel 2.2.7......", "wget https://raw.githubusercontent.com/Ham-ahmed/28/refs/heads/main/simple-zoom-panel_2.2.7.sh -O - | /bin/sh"),
        ("43.  wireguard-vpn15.1-3.12.24-02-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/242/refs/heads/main/wireguard-vpn_15.1_3.12.sh -O - | /bin/sh"),
        ("43.  wireguard-vpn15.1-3.13.24-02-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/242/refs/heads/main/wireguard-vpn_15.1_3.13.sh -O - | /bin/sh"),
        ("44.  setpicon_v3.0-py3................", "wget https://raw.githubusercontent.com/Ham-ahmed/133/refs/heads/main/setpicon_v3.0.sh -O - | /bin/sh"),
        ("45.  youtube-1....ffmpeg_177_armv7ahf.py3..", "wget https://raw.githubusercontent.com/Ham-ahmed/233/refs/heads/main/ffmpeg_177_armv7ahf.sh -O - | /bin/sh"),
        ("46.  youtube-2.exteplayer3_177_armv7ahf.py3", "wget https://raw.githubusercontent.com/Ham-ahmed/233/refs/heads/main/exteplayer3_177_armv7ahf.sh -O - | /bin/sh"),
        ("47.  oscamstatus..v6.94... New.plugin......", "wget https://raw.githubusercontent.com/Ham-ahmed/28/refs/heads/main/oscamstatus_6.94.sh -O - | /bin/sh"),
        ("48.  e2iplayer... سورس zadmario............", "wget https://gitlab.com/zadmario/e2iplayer/-/raw/master/install-e2iplayer.sh -O - | /bin/sh"),
        ("49.  auto dcw key add v1.0.6-New-plugin....", "wget https://raw.githubusercontent.com/Ham-ahmed/206/refs/heads/main/auto-dcw-key-add_v1.0.6.sh -O - | /bin/sh"),
        ("50.  keyadder plugin v9.0-New-plugin.......", "wget https://raw.githubusercontent.com/fairbird/KeyAdder/main/installer.sh -O - | /bin/sh"),
        ("51.  backupsuite_3.0_r9-New-plugin.........", "wget https://raw.githubusercontent.com/Ham-ahmed/207/refs/heads/main/backupsuite_3.0-r9.sh -O - | /bin/sh"),
        ("52.  enigma2readeradder-New-plugin.........", "wget https://raw.githubusercontent.com/Ham-ahmed/177/refs/heads/main/enigma2readeradder.sh -O - | /bin/sh"),
        ("53.  multibootselector_1.16-r0-New-plugin..", "wget https://raw.githubusercontent.com/Ham-ahmed/28-8/refs/heads/main/multibootselector_1.16-r0.sh -O - | /bin/sh"),
        ("54.  servicescanupdates-v3.2-New-plugin....", "wget https://raw.githubusercontent.com/Ham-ahmed/198/refs/heads/main/ervicescanupdates_v3.2.sh -O - | /bin/sh"),
        ("55.  FeedCatcher.sh.v1.1-New-plugin........", "wget https://raw.githubusercontent.com/Ham-ahmed/118/refs/heads/main/FeedCatcher.sh -O - | /bin/sh"),
        ("56.  auto-dcw-key-add v1.0.8-New-plugin....", "wget https://raw.githubusercontent.com/Ham-ahmed/28-8/refs/heads/main/auto-dcw-key-add_v1.0.8.sh -O - | /bin/sh"),
        ("57.  raedquicksignal_18.0-By-BO-hlala-New..", "wget https://raw.githubusercontent.com/Ham-ahmed/28-8/refs/heads/main/raedquicksignal_18.0-By-BO-hlala.sh -O - | /bin/sh"),
     ],
          "10.  Novaler": [
        ("1.   novalerstore....py3.13", "wget http://ipk.ath.cx/pg/novalerstore-py3.13.sh -O - | /bin/sh"),
        ("2.   novalerstore....py3.12", "wget http://ipk.ath.cx/pg/novalerstore-py3.12.sh -O - | /bin/sh"),
        ("3.   novalerstore....py3-11", "wget http://ipk.ath.cx/pg/novalerstore-py3.11.sh -O - | /bin/sh"),
        ("4.   novalerstore...py3-9.9", "wget http://ipk.ath.cx/pg/novalerstore-py3.9.sh -O - | /bin/sh"),
        ("5.   ipaudioplus.....py3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipaudioplus-py3.12_4.1-r0_all.sh -O - | /bin/sh"),
        ("6.   ipaudioplus.....py3-11", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipaudioplus-py3.11_4.1-r0_all.sh -O - | /bin/sh"),
        ("7.   ipaudioplus....py3-9.9", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipaudioplus-py3.9_4.1-r0_all.sh -O - | /bin/sh"),
        ("8.   ipsat...........py3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipsat-py3.12_9.5-r0_all.sh -O - | /bin/sh"),
        ("9.   ipsat...........py3-11", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipsat-py3.11_9.5-r0_all.sh -O - | /bin/sh"),
        ("10.  ipsat..........py3-9.9", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipsat-py3.9_9.5-r0_all.sh -O - | /bin/sh"),
        ("11.  novacampro......py3.13", "wget http://ipk.ath.cx/pg/novacam-py3.13.sh -O - | /bin/sh"),
        ("12.  novacampro......py3.12", "wget http://ipk.ath.cx/pg/novacam-py3.12.sh -O - | /bin/sh"),
        ("13.  novacampro......py3.11", "wget http://ipk.ath.cx/pg/novacam-py3.11.sh -O - | /bin/sh"),
        ("14.  novacampro.......py3.9", "wget http://ipk.ath.cx/pg/novacam-py3.9.sh -O - | /bin/sh"),
        ("15.  beengo..........py3.12", "wget http://ipk.ath.cx/pg/beengo-py3.13.sh  -O - | /bin/sh"),
        ("16.  beengo..........py3.12", "wget http://ipk.ath.cx/pg/beengo-py3.12.sh -O - | /bin/sh"),
        ("17.  beengo..........py3-11", "wget http://ipk.ath.cx/pg/beengo-py3.11.sh -O - | /bin/sh"),
        ("18.  beengo.........py3-9.9", "wget http://ipk.ath.cx/pg/beengo-py3.9.sh -O - | /bin/sh"),
        ("19.  novalertv.......py3.13", "wget http://ipk.ath.cx/pg/novalertv-py3.13.sh -O - | /bin/sh"),
        ("20.  novalertv.......py3.12", "wget http://ipk.ath.cx/pg/novalertv-py3.12.sh -O - | /bin/sh"),
        ("21.  novalertv.......py3-11", "wget http://ipk.ath.cx/pg/novalertv-py3.11.sh -O - | /bin/sh"),
        ("22.  novalertv......py3-9.9", "wget http://ipk.ath.cx/pg/novalertv-py3.9.sh -O - | /bin/sh"),
        ("23.  novatv..........py3.13", "wget http://ipk.ath.cx/pg/novatv-py3.13.sh -O - | /bin/sh"),
        ("24.  novatv..........py3.12", "wget http://ipk.ath.cx/pg/novatv-py3.12.sh -O - | /bin/sh"),
        ("25.  novatv..........py3-11", "wget http://ipk.ath.cx/pg/novatv-py3.11.sh -O - | /bin/sh"),
        ("26.  novatv.........py3-9.9", "wget http://ipk.ath.cx/pg/novatv-py3.9.sh -O - | /bin/sh"),
    ],
          "11. Others-Panel": [
        ("1.   levi45-addon...manager10.1r28", "wget https://raw.githubusercontent.com/Ham-ahmed/43/refs/heads/main/installer-addon18.0-r28.sh -O - | /bin/sh"),
        ("2.   levi45emulator_1.0...........", "wget https://raw.githubusercontent.com/Ham-ahmed/198/refs/heads/main/levi45emulator_1.0.sh -O - | /bin/sh"),
        ("3.   levi45-multicammanager10.2r2.", "wget https://raw.githubusercontent.com/levi-45/Manager/main/installer.sh-O - | /bin/sh"),
        ("4.   oscam-emu-levi45....11885-802", "wget https://raw.githubusercontent.com/Ham-ahmed/177/refs/heads/main/oscam-emu-levi45_11885-802.sh -O - | /bin/sh"),
        ("5.   levi45-multicammanager10.1r33", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/levi45multicammanager_10.1-r33.sh -O - | /bin/sh"),
        ("6.   oscam-emu-levi45....11884-802", "wget https://raw.githubusercontent.com/Ham-ahmed/105/refs/heads/main/oscam-emu-levi45_11884-802.sh -O - | /bin/sh"),
        ("7.   oscam-emu-levi45....11868-802", "wget https://raw.githubusercontent.com/Ham-ahmed/22/refs/heads/main/oscam-emu-levi45_11868-802.sh -O - | /bin/sh"),
        ("8.   oscam-emu-levi45....11865-802", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/oscam-emu-levi45_11865-802.sh -O - | /bin/sh"),
        ("9.   oscam-emu-levi45....11862-802", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/oscam-emu-levi45_11862-802.sh -O - | /bin/sh"),
        ("10.  oscam-emu-levi45....11861-802", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/oscam-emu-levi45_11861-802.sh -O - | /bin/sh"),
        ("11.  oscam-emu-levi45....11860-802", "wget https://raw.githubusercontent.com/Ham-ahmed/oscam11860/refs/heads/main/oscam-emu-levi45_11860-802.sh -O - | /bin/sh"),
        ("12.  oscam-emu-levi45....11858-802", "wget https://raw.githubusercontent.com/Ham-ahmed/Levi45/refs/heads/main/oscam-emu-levi45_11858-802.sh -O - | /bin/sh"),
        ("13.  oscam-emu-levi45....11856-802", "wget https://raw.githubusercontent.com/Ham-ahmed/others2/refs/heads/main/oscam-emu-levi45_11856-802.sh -O - | /bin/sh"),
        ("14.  oscam-emu-levi45....11854-802", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/oscam-emu-levi45_11854-802.sh -O - | /bin/sh"),
        ("15.  oscam-emu-levi45....11849-802", "wget https://raw.githubusercontent.com/Ham-ahmed/others2/refs/heads/main/oscam-emu-levi45_11849-802.sh -O - | /bin/sh"),
        ("16.  oscam-emu-levi45....11847-802", "wget https://raw.githubusercontent.com/Ham-ahmed/others2/refs/heads/main/oscam-emu-levi45_11847-802.sh -O - | /bin/sh"),
        ("17.  oscamicamall_V.9.2-Kitte888..", "wget https://raw.githubusercontent.com/Ham-ahmed/238/refs/heads/main/oscamicamall_V.9.2-Kitte888.sh -O - | /bin/sh"),
        ("18.  oscamicamnew....11857-ICAMEMU", "wget https://raw.githubusercontent.com/Ham-ahmed/Levi45/refs/heads/main/oscamicamnew_11857-ICAMEMU-Kitte888.sh -O - | /bin/sh"),
        ("19.  oscamicamnew....11847-ICAMEMU", "wget https://raw.githubusercontent.com/Ham-ahmed/others2/refs/heads/main/oscamicamnew_11847-ICAMEMU-Kitte888.sh -O - | /bin/sh"),
        ("20.  oscam-emu-levi45....11845-802", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/oscam-emu-levi45_11845-802.sh -O - | /bin/sh"),
        ("21.  oscamicamnew....11886-ICAMEMU", "wget https://raw.githubusercontent.com/Ham-ahmed/88/refs/heads/main/oscamicamnewtest_11886-ICAMEMUTEST.sh -O - | /bin/sh"),
        ("22.  oscamicamnew....11868-ICAMEMU", "wget https://raw.githubusercontent.com/Ham-ahmed/83/refs/heads/main/oscamicamnew_11868-ICAMEMU-Kitte888.sh -O - | /bin/sh"),
        ("23.  oscamicamnew....11845-ICAMEMU", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/oscamicamnew_11845-ICAMEMU-Kitte888.sh -O - | /bin/sh"),
        ("24  oscam emu 11881 802 audi06_19", "wget https://raw.githubusercontent.com/Ham-ahmed/294/refs/heads/main/oscam-11881-emu-802.sh -O - | /bin/sh"),
        ("25.  CiefpsettingsPanel-v.2.......", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/installer.sh -O - | /bin/sh"),
        ("26.  levi45-settings_1.2..........", "wget https://raw.githubusercontent.com/Ham-ahmed/206/refs/heads/main/levi45-settings_1.2.sh -O - | /bin/sh"),
        ("27.  panelaio_1.6.................", "wget https://raw.githubusercontent.com/Ham-ahmed/28/refs/heads/main/panelaio_1.6.sh -O - | /bin/sh"),
        ("27.  CiefpOscamEditor-1.2.0.......", "wget https://raw.githubusercontent.com/ciefp/CiefpOscamEditor/main/installer.sh -O - | /bin/sh"),
    ],
          "12. Cam-Emulator": [
        ("1.   Ncam-emu_v15.4-r0.New....fairman", "wget https://raw.githubusercontent.com/biko-73/Ncam_EMU/main/installer.sh -O - | /bin/sh"),
        ("1-1. Ncam-emu_v15.2-r0........fairman", "wget https://raw.githubusercontent.com/Ham-ahmed/2412/refs/heads/main/ncam_15.2-r0_all.sh -O - | /bin/sh"),
        ("2-1. Ncam-emu_v15.1-r0........fairman", "wget https://raw.githubusercontent.com/Ham-ahmed/softcam-emu/refs/heads/main/ncam_15.1-r0_all.sh -O - | /bin/sh"),
        ("4.   oscam-emu_11868.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/22/refs/heads/main/oscam_11868-emu-r802.sh -O - | /bin/sh"),
        ("5.   power-11868...........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/22/refs/heads/main/powercam-oscam_11868-emu-r802.sh -O - | /bin/sh"),
        ("6.   supcam-11868..........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/22/refs/heads/main/supcam-oscam_11868-emu-r802.sh -O - | /bin/sh"),
        ("7.   ultaracam-11868.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/22/refs/heads/main/ultracam-oscam_11868-emu-r802.sh -O - | /bin/sh"),
        ("8.   gosatplus-oscam_11868_mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/22/refs/heads/main/gosatplus-oscam_11868-emu-r802.sh -O - | /bin/sh"),
        ("9.   oscam-emu_11870-802....audi06-19", "wget https://raw.githubusercontent.com/Ham-ahmed/43/refs/heads/main/oscam-11870-emu-802-audi06_19.sh -O - | /bin/sh"),
        ("10.  oscam-emu_11866.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/oscam_11866-emu-r802.sh -O - | /bin/sh"),
        ("11.  power-11866...........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/powercam-oscam_11866-emu-r802.sh -O - | /bin/sh"),
        ("12.  supcam-11866..........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/supcam-oscam_11866-emu-r802.sh -O - | /bin/sh"),
        ("13.  ultaracam-11866.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/ultracam-oscam_11866-emu-r802.sh -O - | /bin/sh"),
        ("14.  gosatplus-oscam_11866_mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/gosatplus-oscam_11866-emu-r802.sh -O - | /bin/sh"),
        ("15.  oscam-emu_11865.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/oscam_11865-emu-r802.sh -O - | /bin/sh"),
        ("16.  power-11865...........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/powercam-oscam_11865-emu-r802.sh -O - | /bin/sh"),
        ("17.  supcam-11865..........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/supcam-oscam_11865-emu-r802.sh -O - | /bin/sh"),
        ("18.  ultaracam-11865.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/ultracam-oscam_11865-emu-r802.sh -O - | /bin/sh"),
        ("19.  gosatplus-oscam11865..mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/gosatplus-oscam_11865-emu-r802.sh -O - | /bin/sh"),
        ("20.  oscam-emu_11884-802....audi06-19", "wget https://raw.githubusercontent.com/Ham-ahmed/105/refs/heads/main/oscam-11884-emu-802.sh -O - | /bin/sh"),
        ("21.  oscam-emu_11863.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/oscam_11863-emu-r802.sh -O - | /bin/sh"),
        ("22.  power-11863...........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/powercam-oscam_11863-emu-r802.sh -O - | /bin/sh"),
        ("23.  supcam-11863..........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/supcam-oscam_11863-emu-r802.sh -O - | /bin/sh"),
        ("24.  ultaracam-11863.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/ultracam-oscam_11863-emu-r802.sh -O - | /bin/sh"),
        ("25.  gosatplus-oscam_11863_mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/gosatplus-oscam_11863-emu-r802.sh -O - | /bin/sh"),
        ("26.  oscam-emu_11862-802....audi06-19", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/oscam-emu_11862-802-arm-mips_audi06-19.sh -O - | /bin/sh"),
        ("27.  oscam-emu_11860.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/oscam11860/refs/heads/main/oscam_11860-emu-r802.sh -O - | /bin/sh"),
        ("28.  power-11860...........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/oscam11860/refs/heads/main/powercam-oscam_11860-emu-r802.sh -O - | /bin/sh"),
        ("29.  supcam-11860..........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/oscam11860/refs/heads/main/supcam-oscam_11860-emu-r802.sh -O - | /bin/sh"),
        ("30.  ultaracam-11860.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/oscam11860/refs/heads/main/ultracam-oscam_11860-emu-r802.sh -O - | /bin/sh"),
        ("31.  gosatplus-oscam_11860_mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/oscam11860/refs/heads/main/gosatplus-oscam_11860-emu-r802.sh -O - | /bin/sh"),
        ("32.  oscam-all-images_11884-emu-802..", "wget https://raw.githubusercontent.com/Ham-ahmed/206/refs/heads/main/oscam-all-images_11884-emu-802.sh -O - | /bin/sh"),
    ],
          "13. Backup-build": [
        ("1.   ajpanel-v10.8.3..................", "wget https://raw.githubusercontent.com/Ham-ahmed/155/refs/heads/main/ajpanel_v10.8.3.sh -O - | /bin/sh"),
        ("2.   ArabicSavior..............For All", "wget https://raw.githubusercontent.com/fairbird/ArabicSavior/main/installer.sh -O - | /bin/sh"),
        ("3.   EpgGrabber-24.2...............All", "wget https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh -O - | /bin/sh"),
        ("-.   EpgGrabber-23.5...............All", "wget https://raw.githubusercontent.com/Ham-ahmed/EPG/main/epg-plugin-master-v23.5.sh -O - | /bin/sh"),
        ("4.   subssupport-v1.7.0-r19-D.Mnasr...", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.shoplus-py3.11_4.1-r0_all.sh -O - | /bin/sh"),
        ("-.   subssupport-v1.7.0-r7..mora-Mnasr", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/refs/heads/main/subssupport-install.sh -O - | /bin/sh"),
        ("-.   subssupport-v1.7.0 r5..mora-Mnasr", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("-.   subssupport.........By_Mora Hosny", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh  -O - | /bin/sh"),
        ("4.   xtraevent5.3.....................", "wget https://raw.githubusercontent.com/Ham-ahmed/283/refs/heads/main/xtraevent_6.820.sh  -O - | /bin/sh"),
        ("-.   xtraevent5.3.....................", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/xtraevent-5.3.sh  -O - | /bin/sh"),
        ("5.   Ncam-emu..................v15.2r0", "wget https://raw.githubusercontent.com/Ham-ahmed/2412/refs/heads/main/ncam_15.2-r0_all.sh -O - | /bin/sh"),
        ("6.   oscam-emu........11868_mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/22/refs/heads/main/oscam_11868-emu-r802.sh -O - | /bin/sh"),
        ("7.   keyadder plugin v9.0-New-plugin..", "wget https://raw.githubusercontent.com/fairbird/KeyAdder/main/installer.sh -O - | /bin/sh"),
        ("8.   RaedQuickSignal.............v17.4", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/RaedQuickSignalv17.4.sh -O - | /bin/sh"),
        ("9.   multi-stalkerpro-v1.2openAtv7.5.1", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/Mstalker/MultiStalkerPro_Atv.sh -O - | /bin/sh"),
        ("-.   multistalker-pro.............v1.2", "wget https://raw.githubusercontent.com/Ham-ahmed/backup/main/multistalker-pro_v1.2.sh -O - | /bin/sh"),
        ("-.   multistalker-pro.............v1.1", "wget https://raw.githubusercontent.com/Ham-ahmed/112024/refs/heads/main/multi-stalkerpro_1.1.sh -O - | /bin/sh"),
        ("-.   multistalker-pro.v1.2.....py3.9.9", "wget https://raw.githubusercontent.com/Ham-ahmed/83/refs/heads/main/multi-stalkerpro-1.2.sh -O - | /bin/sh"),
        ("10.  bouquetmakerxtream...........1.18", "wget https://raw.githubusercontent.com/Ham-ahmed/Iptv-plugin/main/bouquetmakerxtream_pliugin1.18.20240723.sh -O - | /bin/sh"),
        ("11.  Bosnia_ukrania............Package", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/Bosnia_ukrania-MStream.sh -O - | /bin/sh"),
        ("12.  ukrania_Bouquet..............4.9e", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/ukrania_MStream_4.9e.sh -O - | /bin/sh"),
        ("13.  astra-sm-arm..................0.2", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/astra-sm_0.2-r0.sh -O - | /bin/sh"),
        ("14.  ukrania_config...............0109", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/ukrania_config_0109.sh -O - | /bin/sh"),
        ("15.  e2iplayer........................", "wget https://gitlab.com/MOHAMED_OS/e2iplayer/-/raw/main/install-e2iplayer.sh -O - | /bin/sh"),
        ("16.  Xklass-1.47......................", "wget https://raw.githubusercontent.com/Ham-ahmed/154/refs/heads/main/xklass_1.47.sh -O - | /bin/sh"),
        ("17.  vavoo.......................v1.22", "wget https://raw.githubusercontent.com/Ham-ahmed/newp/main/vavoo_v1.22.sh -O - | /bin/sh"),
        ("18.  iptosat.......................1.8", "wget https://gitlab.com/eliesat/extensions/-/raw/main/iptosat/iptosat.sh -O - | /bin/sh"),
        ("19.  bouquetmakerxtream.v1.48.........", "wget https://raw.githubusercontent.com/Ham-ahmed/154/refs/heads/main/bouquetmakerxtream_1.48.sh -O - | /bin/sh"),
        ("20.  jedimakerxtream-6.39.............", "wget https://raw.githubusercontent.com/Ham-ahmed/122/refs/heads/main/jedimakerxtream_6.39.sh -O - | /bin/sh"),
        ("21.  Tmbd-v.8.6..............py 3.11.2", "wget https://raw.githubusercontent.com/biko-73/TMBD/main/installer.sh -O - | /bin/sh"),
        ("22.  Bosnia................Bouquet-16e", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/Bosnia_MStream_16e.sh -O - | /bin/sh"),
        ("23.  astra-sm..................arm-0.2", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/astra-sm_0.2-r0.sh -O - | /bin/sh"),
        ("24.  astra_config.................0507", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/astra_config_050724.sh -O - | /bin/sh"),
        ("25.  History_Zap_1.0.38.........py3.12", "wget https://raw.githubusercontent.com/biko-73/History_Zap_Selector/main/installer.sh -O - | /bin/sh"),
        ("26.  oaweather2.6.....................", "wget https://raw.githubusercontent.com/Ham-ahmed/1New-P/main/oaweather.sh -O - | /bin/sh"),
        ("27.  weather-plugin...............v2.1", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/weatherplugin_2.1_all.sh -O - | /bin/sh"),
    ],
              "14. Iptv-player": [
        ("1.   estalker_1.11..........23-08-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/238/refs/heads/main/estalker_0.11.sh -O - | /bin/sh"),      
        ("2.   Xklass-1.60............17-07-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/88/refs/heads/main/xklass_1.60.sh -O - | /bin/sh"),      
        ("-.   Xklass-1.49............29-04-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/294/refs/heads/main/xklass_1.49.sh -O - | /bin/sh"),      
        ("-.   Xklass-1.47............15-04-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/154/refs/heads/main/xklass_1.47.sh -O - | /bin/sh"),     
        ("-.   Xklass-1.44............06-04-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/64/refs/heads/main/xklass_1.44.sh -O - | /bin/sh"),
        ("-.   Xklass-1.43............28-03-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/283/refs/heads/main/xklass_1.43.sh -O - | /bin/sh"),
        ("-.   Xklass-1.38............13-03-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/133/refs/heads/main/xklass_1.38.sh -O - | /bin/sh"),
        ("-.   Xklass-1.35.............03-2-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/122/refs/heads/main/xklass_1.35.sh -O - | /bin/sh"),   
        ("-.   Xklass-1.33.............03-2-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/32/refs/heads/main/xklass_1.33_all.sh -O - | /bin/sh"),
        ("3.   xstreamity..v5.09......08-08-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/198/refs/heads/main/xstreamity_5.09.sh -O - | /bin/sh"),
        ("-.   xstreamity..v4.95......15-04-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/154/refs/heads/main/xstreamity_4.95.sh -O - | /bin/sh"),
        ("-.   xstreamity..v4.92......06-04-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/283/refs/heads/main/xstreamity_4.90.sh -O - | /bin/sh"),
        ("-.   xstreamity..v4.90.......28-3-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/283/refs/heads/main/xstreamity_4.90.sh -O - | /bin/sh"),
        ("-.   xstreamity..v4.88.......10-3-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/93/refs/heads/main/xstreamity_4.88.sh -O - | /bin/sh"),
        ("-.   xstreamity..v4.86.......24-2-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/242/refs/heads/main/xstreamity_4.86.sh -O - | /bin/sh"),
        ("-.   xstreamity..v4.83..21-2-2025.....", "wget https://raw.githubusercontent.com/Ham-ahmed/2102/refs/heads/main/xstreamity_4.83.sh -O - | /bin/sh"),
        ("-.   xstreamity..v4.75..03-2-2025.....", "wget https://raw.githubusercontent.com/Ham-ahmed/32/refs/heads/main/xstreamity_4.75.sh -O - | /bin/sh"),
        ("4.   jedimakerxtream..................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/jedimakerxtream/jedimakerxtream.sh -O - | /bin/sh"),
        ("-.   jedimakerxtream.v6.40............", "wget https://raw.githubusercontent.com/Ham-ahmed/2102/refs/heads/main/jedimakerxtream_6.40.sh -O - | /bin/sh"),
        ("5.   bouquetmakerxtream.v1.60.........", "wget https://raw.githubusercontent.com/Ham-ahmed/118/refs/heads/main/bouquetmakerxtream_1.60.sh -O - | /bin/sh"),
        ("-.   bouquetmakerxtream.v1.48.........", "wget https://raw.githubusercontent.com/Ham-ahmed/154/refs/heads/main/bouquetmakerxtream_1.48.sh -O - | /bin/sh"),
        ("-.   bouquetmakerxtream.v1.47.........", "wget https://raw.githubusercontent.com/Ham-ahmed/64/refs/heads/main/bouquetmakerxtream_1.47.sh -O - | /bin/sh"),
        ("6.   vavoo-maker_1.38..............New", "wget https://raw.githubusercontent.com/Ham-ahmed/206/refs/heads/main/vavoo_1.38.sh -O - | /bin/sh"),
        ("7.   iptosat.......................1.8", "wget https://gitlab.com/eliesat/extensions/-/raw/main/iptosat/iptosat.sh -O - | /bin/sh"),
        ("8.   xcplugin_forever.............v4.3", "wget https://raw.githubusercontent.com/Belfagor2005/xc_plugin_forever/main/installer.sh -O - | /bin/sh"),
        ("9.   multi-stalkerpro-v1.2.....openAtv", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/multi-stalkerpro_Atv-py3.-12-8.sh -O - | /bin/sh"),
        ("-.   multistalker-pro.............v1.2", "wget https://raw.githubusercontent.com/Ham-ahmed/backup/main/multistalker-pro_v1.2.sh -O - | /bin/sh"),
        ("-.   multistalker-pro.............v1.1", "wget https://raw.githubusercontent.com/Ham-ahmed/112024/refs/heads/main/multi-stalkerpro_1.1.sh -O - | /bin/sh"),
        ("10.  stalkerportalconverter......v1.3", "wget https://raw.githubusercontent.com/Ham-ahmed/206/refs/heads/main/stalkerportalconverter_1.3.sh -O - | /bin/sh"),
    ],
         "15. Audio-files": [
        ("1.   Ipaudiopro-1.5......py3.12.4-5-6", "wget https://raw.githubusercontent.com/zKhadiri/IPAudioPro-Releases-/refs/heads/main/installer.sh -O - | /bin/sh"),
        ("2.   Ipaudiopro-1.5.Corvoboys.py3.9.9", "wget https://raw.githubusercontent.com/Ham-ahmed/83/refs/heads/main/ipaudiopro_1.5_3.9.9.sh -O - | /bin/sh"),
        ("3.   Ipaudiopro-1.4......py3.12.4-5-6", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/refs/heads/main/ipaudiopro_1.4.sh -O - | /bin/sh"),
        ("4.   ipaudiopro-haitham_Aniss+audio..", "wget https://raw.githubusercontent.com/Ham-ahmed/20-5/refs/heads/main/ipaudiopro-haitham.sh -O - | /bin/sh"),
        ("5.   Ipaudiopro-1.3........py3.12.4-5", "wget https://raw.githubusercontent.com/biko-73/ipaudio/main/ipaudiopro.sh -O - | /bin/sh"),
        ("6.   Ipaudiopro.......openvix_6.6.001", "wget https://raw.githubusercontent.com/Ham-ahmed/Ipaudio-2024/main/ipaudiopro_1.1-r2.sh -O - | /bin/sh"),
        ("7.   M-Elsaftyv1.1....r6_picons+audio", "wget https://raw.githubusercontent.com/Ham-ahmed/Ipaudio-2024/main/ipaudiopro1.1-r2-Elsafty.sh -O - | /bin/sh"),
        ("8.   Ipaudiopro-v1.1...........py3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/Ipaudio-2024/main/ipaudiopro-py3.12_v1.1-By-Zakaria.sh -O - | /bin/sh"),
    ],
         "16. Picons": [
        ("1.   chocholousek......plugin", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/chocholousek-picons_5.0.240904.sh -O - | /bin/sh"),
        ("2.   piconinstaller....plugin", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/piconinstaller_24.08.26_all.sh -O - | /bin/sh"),
        ("3.   picons_All-Sat_30-3-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons_All-Sat_28-3-2024.sh -O - | /bin/sh"),
        ("4.   picons-30.0W.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-30.0W_2032024.sh -O - | /bin/sh"),
        ("5.   Nilsat7.0w-8.0w..2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-Nilsat7.0w-8.0w_2032024.sh -O - | /bin/sh"),
        ("6.   picons-7.0W......2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-7.0W_2032024.sh -O - | /bin/sh"),
        ("7.   picons-8.0W......2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-8.0W_2032024.sh -O - | /bin/sh"),
        ("8.   picons-4.0W......2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-4.0W_2032024.sh -O - | /bin/sh"),
        ("9.   picons-1.0W-0.8W_2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-1.0W-0.8W_2032024.sh -O - | /bin/sh"),
        ("10.  picons-1.9E......2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-1.9E_2032024.sh -O - | /bin/sh"),
        ("11.  picons-7.0E......2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-7.0E_2032024.sh -O - | /bin/sh"),
        ("12.  picons-9.0E......2832024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-9.0E_2832024.sh -O - | /bin/sh"),
        ("13.  picons-13.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-13.0E_2032024.sh -O - | /bin/sh"),
        ("14.  picons-16.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-16.0E_2032024.sh -O - | /bin/sh"),
        ("15.  picons-19.2E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-19.2E_2032024.sh -O - | /bin/sh"),
        ("16.  picons-21.5E.....2832024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-21.5E_28032024.sh -O - | /bin/sh"),
        ("17.  picons-23.5E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-23.5E_2032024.sh -O - | /bin/sh"),
        ("18.  picons-26.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-26.0E_2032024.sh -O - | /bin/sh"),
        ("19.  picons-39.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-39.0E_2032024.sh -O - | /bin/sh"),
        ("20.  picons-42.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-42.0E_2032024.sh -O - | /bin/sh"),
        ("21.  picons-45.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-45.0E_2032024.sh -O - | /bin/sh"),
        ("10.  picons-46.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-46.0E_2032024.sh -O - | /bin/sh"),
        ("11.  picons-51.5E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-51.5E_2032024.sh -O - | /bin/sh"),
        ("12.  picons-52.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-52.0E_2032024.sh -O - | /bin/sh"),
        ("13.  picons-53.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-53.0E_2032024.sh -O - | /bin/sh"),
        ("14.  picons-54.9E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-54.9E_2032024.sh -O - | /bin/sh"),
        ("15.  picons-62.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-62.0E2032024.sh -O - | /bin/sh"),
        ("16.  picons-68.5E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-68.5E_2032024 -O - | /bin/sh"),
        ("17.  picons_NilSat.........8W", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-Nilsat-8w-01032024.sh -O - | /bin/sh"),
        ("18.  picons_NilSat-8W.....26E", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-Nilsat-8w-26e_01032024.sh -O - | /bin/sh"),
    ],
    "17. Tools": [
        ("1.   astra-sm-arm....0.2", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/astra-sm_0.2-r0.sh -O - | /bin/sh"),
        ("2.   astra_config...0507", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/astra_config_050724.sh -O - | /bin/sh"),
        ("3.   opdboot............", "wget https://gitlab.com/eliesat/extensions/-/raw/main/opdboot/opdboot.sh -O - | /bin/sh"),
        ("4.   opkg-tools.........", "wget https://gitlab.com/eliesat/extensions/-/raw/main/opkg-tools/opkg-tools.sh -O - | /bin/sh"),
        ("5.   oscam-status.......", "wget https://gitlab.com/eliesat/extensions/-/raw/main/oscam-status/oscam-status.sh -O - | /bin/sh"),
        ("6.   plutotv............", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipaudioplus-py3.9_4.1-r0_all.sh -O - | /bin/sh"),
        ("7.   xml update.........", "wget opkg install enigma2-plugin-systemplugins-xmlupdate -O - | /bin/sh"),
        ("8.   bitrate2.0.........", "wget https://gitlab.com/eliesat/extensions/-/raw/main/bitrate/bitrate.sh -O - | /bin/sh"),
        ("9.   quarter-pounder....", "wget https://gitlab.com/eliesat/extensions/-/raw/main/quarter-pounder/quarter-pounder.sh -O - | /bin/sh"),
        ("10.  arabicsavior.......", "wget https://gitlab.com/eliesat/extensions/-/raw/main/arabic-savior/arabicsavior.sh -O - | /bin/sh"),
        ("11.  bitrate-ahmedriad..", "wget https://gitlab.com/eliesat/extensions/-/raw/main/bitrate/bitrate-mod-ariad.sh -O - | /bin/sh"),
        ("12.  permanentclock.....", "wget opkg install enigma2-plugin-extensions-permanentclock -O - | /bin/sh"),
        ("13.  service_app........", "wget opkg install enigma2-plugin-systemplugins-serviceapp -O - | /bin/sh"),
        ("14.  service_app........", "wget https://raw.githubusercontent.com/Ham-ahmed/HAmed-Scripts/main/NewVirtualKeyBoard_sub.sh -O - | /bin/sh"),
        ("15.  New-Sherlockmod....", "wget https://raw.githubusercontent.com/biko-73/Sherlockmod/main/installer.sh -O - | /bin/sh"),
        ("16.  internet-speed-test", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/internet-speed-test-1.7.sh -O - | /bin/sh"),
        ("17.  Ghost-Net_Arabization", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/internet-speed-test-1.7.sh -O - | /bin/sh"),
    ],
    "18. Multiboot": [
        ("1.   neoboot..........9.65", "wget https://raw.githubusercontent.com/Ham-ahmed/212/refs/heads/main/neoboot-v9.65.sh -O - | /bin/sh"),
        ("2.   opdboot...........3.1", "wget https://raw.githubusercontent.com/Ham-ahmed/1New-P/main/opdboot-v3.1.sh -O - | /bin/sh"),
        ("3.   multiboot-flashonline", "wget https://gitlab.com/eliesat/extensions/-/raw/main/multiboot-flashonline/multiboot-flashonline.sh -O - | /bin/sh"),
    ],
    "19. remove": [
        ("1.   aglare_Skin-remove...", "wget https://raw.githubusercontent.com/Ham-ahmed/Remove/main/aglare_remove.sh -O - | /bin/sh"),
        ("2.   aglarepli-Skin_remove", "wget https://raw.githubusercontent.com/Ham-ahmed/Remove/main/aglarepli_remove.sh -O - | /bin/sh"),
        ("3.   Crash-logo...........", "wget https://gitlab.com/eliesat/scripts/-/raw/main/remove/_remove-crash-logs.sh -O - | /bin/sh"),
    ],
    "20. Bootlogo All": [
        ("1.   atv share.....3-bootlogo", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/bootlogo/a-tv/bootlogo-atv-share.sh -O - | /bin/sh"),
        ("2.   atv Swapper...8-bootlogo", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/bootlogo/a-tv/bootlogos-atv_swa.sh -O - | /bin/sh"),
        ("3.   openvix...share3bootlogo", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/bootlogo/vix/bootlogo-vix-share.sh -O - | /bin/sh"),
        ("4.   openvix...Swap8-bootlogo", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/bootlogo/vix/bootlogos-vix_swa.sh -O - | /bin/sh"),
        ("5.   teamblue share3-bootlogo", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/bootlogo/t-blue/bootlogo-Tblue-share.sh -O - | /bin/sh"),
        ("7.   teamblue Swap.8-bootlogo", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/bootlogo/t-blue/bootlogos-Tblue_swa.sh -O - | /bin/sh"),
        ("8.   bootlogoswapper.........", "wget https://gitlab.com/eliesat/extensions/-/raw/main/bootlogoswapper/bootlogoswapper-eliesat-special-edition.sh -O - | /bin/sh"),
        ("9.   Egami-logo..............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-egami.sh -O - | /bin/sh"),
        ("10.  Egami-logo..............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-novaler.sh"),
        ("11.  openspa-logo............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openspa.sh -O - | /bin/sh"),
        ("12.  pure2-logo..............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-pure2.sh -O - | /bin/sh"),
        ("13.  openvix-logo............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openvix.sh -O - | /bin/sh"),
        ("14.  openvix-logo............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openvix.sh -O - | /bin/sh"),
        ("15.  openvix-logo............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openfix.sh -O - | /bin/sh"),
        ("16.  openatv-logo............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openatv.sh -O - | /bin/sh"),
        ("17.  openbh-logo.............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openblackhole.sh -O - | /bin/sh"),
        ("18.  opendroid-logo..........", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-opendroid.sh -O - | /bin/sh"),
        ("19.  openeight-logo..........", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openeight.sh -O - | /bin/sh"),
        ("20.  openhdf-logo............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openhdf.sh -O - | /bin/sh"),
        ("21.  opennfr-logo............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-opennfr.sh -O - | /bin/sh"),
        ("22.  openpli-logo............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openpli.sh -O - | /bin/sh"),
        ("23.  pkteam-logo.............", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-pkteam.sh -O - | /bin/sh"),
    ],
    "21. Fix-IT": [
        ("1.   fix-atv-Softcam........", "wget https://gitlab.com/eliesat/scripts/-/raw/main/all/_fix-atv-softcam-restart.sh -O - | /bin/sh"),
        ("2.   fix-Xtraevent-place....", "wget https://gitlab.com/eliesat/scripts/-/raw/main/all/_fix-xtraevent-download-place.sh -O - | /bin/sh"),
        ("3.   fix-Ipk-package-install", "wget https://gitlab.com/eliesat/scripts/-/raw/main/all/_fix-ipk-package-installation.sh -O - | /bin/sh"),
        ("4.   Xtraevent..............", "wget https://gitlab.com/eliesat/scripts/-/raw/main/all/_fix-xtraevent-download-place.sh -O - | /bin/sh"),
    ],
    "22. Others-plugin": [
        ("1.   ciefp_plugin-v1.5..New........", "wget https://raw.githubusercontent.com/ciefp/CiefpPlugins/main/installer.sh -O - | /bin/sh"),
        ("2.   Ciefp satellite analyzer..New.", "wget https://raw.githubusercontent.com/ciefp/CiefpSatelliteAnalyzer/main/installer.sh -O - | /bin/sh"),
        ("3.  CiefpOscamEditor-1.2.0.........", "wget https://raw.githubusercontent.com/ciefp/CiefpOscamEditor/main/installer.sh -O - | /bin/sh"),        
    ],
    "23. Multi-Media": [
        ("1.   E2IPlayer+Tsplayer..by-biko", "wget https://raw.githubusercontent.com/biko-73/E2IPlayer/main/installer_E2.sh -O - | /bin/sh"),
    ],
    }
        self.current_sub_menu = []
        self.focus = "main_menu"

        self["main_menu"] = MenuList(self.main_menu)
        self["sub_menu"] = MenuList(self.current_sub_menu)
        self["status"] = Label("Select a category to view items")
        self["key_red"] = Button("Exit")
        self["key_green"] = Button("Select")
        self["key_yellow"] = Button("Update Plugin")
        self["key_blue"] = Button("Restart Enigma2")
        self["background1"] = Pixmap()
        self["lan"] = Pixmap()
        self["mod"] = Pixmap()
        self["imag"] = Pixmap()
        self["ver"] = Pixmap()
        self["ppt"] = Pixmap()
        self["inter"] = Pixmap()
        self["receiver_model"] = Label(self.get_receiver_model())
        self["image_type"] = Label(self.get_image_type())
        self["image_version"] = Label(self.get_image_version())
        self["ip_address"] = Label(self.get_router_ip())
        self["python_version"] = Label(self.get_python_version())
        self["internet_status"] = Label(self.get_internet_status())
        
        self.icon= LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/MagicPanel/icon.png"))
        self.background1 = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/MagicPanel/icons/background1.png"))

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok": self.handle_ok,
                "left": self.focus_main_menu,
                "right": self.focus_sub_menu,
                "red": self.close,
                "green": self.execute_item,
                "yellow": self.update_plugin,
                "blue": self.restart_enigma2,
                "up": self.navigate_up,
                "down": self.navigate_down,
                "cancel": self.close,
            },
            -1,
        )

        self["main_menu"].onSelectionChanged.append(self.on_main_menu_selection_changed)

    def focus_main_menu(self):
        self.focus = "main_menu"
        self["main_menu"].selectionEnabled(1)
        self["sub_menu"].selectionEnabled(0)

    def focus_sub_menu(self):
        if self.current_sub_menu:
            self.focus = "sub_menu"
            self["main_menu"].selectionEnabled(0)
            self["sub_menu"].selectionEnabled(1)

    def handle_ok(self):
        if self.focus == "main_menu":
            self.load_sub_menu()
        elif self.focus == "sub_menu":
            self.execute_item()

    def load_sub_menu(self):
        selected = self["main_menu"].getCurrent()
        if selected and selected in self.sub_menus:
            self.current_sub_menu = [item[0] for item in self.sub_menus[selected]]
            self["sub_menu"].setList(self.current_sub_menu)
            self["status"].setText(f"Selected category: {selected}")
            self.focus_sub_menu()

    def on_main_menu_selection_changed(self):
        selected = self["main_menu"].getCurrent()
        if selected and selected in self.sub_menus:
            self.current_sub_menu = [item[0] for item in self.sub_menus[selected]]
            self["sub_menu"].setList(self.current_sub_menu)
            self["status"].setText(f"Showing items for: {selected}")
        else:
            self.current_sub_menu = []
            self["sub_menu"].setList(self.current_sub_menu)
            self["status"].setText("No items available for this category")

    def navigate_up(self):
        if self.focus == "main_menu":
            self["main_menu"].up()
        elif self.focus == "sub_menu":
            self["sub_menu"].up()

    def navigate_down(self):
        if self.focus == "main_menu":
            self["main_menu"].down()
        elif self.focus == "sub_menu":
            self["sub_menu"].down()
            
    def get_python_version(self):
        return f"Python {os.sys.version.split()[0]}"
            
    def get_receiver_model(self):
        try:
            with os.popen("cat /etc/hostname") as f:
                return f.read().strip()
        except Exception:
            return "Unknown Model"

    def get_image_type(self):
        try:
            with os.popen("grep -iF 'creator' /etc/image-version") as f:
                return f.read().strip().replace("creator", "Image")
        except Exception:
            return "Unknown Image"

    def get_image_version(self):
        try:
            with os.popen("grep -iF 'version' /etc/image-version") as f:
                return f.read().strip()
        except Exception:
            return "Unknown Version"
            
    def get_internet_status(self):
        return "INTERNET : Connected" if os.system("ping -c 1 8.8.8.8 > /dev/null 2>&1") == 0 else "INTERNET : No Connection"

    def execute_item(self):
        if self.focus == "sub_menu":
            selected = self["sub_menu"].getCurrent()
            if selected:
                for item in self.sub_menus.get(self["main_menu"].getCurrent(), []):
                    if item[0] == selected:
                        command = item[1]
                        self.session.open(ProgressScreen, command, selected)
                        break

    def update_plugin(self):
        update_command = "wget https://raw.githubusercontent.com/Ham-ahmed/magic/refs/heads/main/MagicPanel_install.sh -O - | /bin/sh"
        self.session.open(ProgressScreen, update_command, "Update Plugin")

    def restart_enigma2(self):
        os.system("killall -9 enigma2")

    def get_router_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except socket.error:
            return "IP not available"

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Magic Panel v6",
            description="Addon plugin For Enigma2",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon=PLUGIN_ICON,
            fnc=lambda session, **kwargs: session.open(MagicPanel),
        ),
    ]



